WITH cust_spend AS (
  SELECT c.customer_id, c.name,
         SUM(CASE WHEN t.txn_type = 'Debit' THEN t.amount ELSE 0 END) AS total_spent
  FROM dbo.customers c
  JOIN dbo.accounts a ON c.customer_id = a.customer_id
  JOIN dbo.transactions t ON a.account_id = t.account_id
  GROUP BY c.customer_id, c.name
)
SELECT customer_id, name, total_spent,
  CASE
    WHEN total_spent > 20000 THEN 'Platinum'
    WHEN total_spent BETWEEN 10000 AND 20000 THEN 'Gold'
    WHEN total_spent BETWEEN 5000 AND 9999.99 THEN 'Silver'
    ELSE 'Bronze'
  END AS tier
FROM cust_spend;