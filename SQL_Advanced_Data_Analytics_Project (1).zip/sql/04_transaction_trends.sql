WITH monthly AS (
  SELECT DATEFROMPARTS(YEAR(txn_date), MONTH(txn_date), 1) AS month_start,
         COUNT(*) AS txn_count,
         SUM(CASE WHEN txn_type='Debit' THEN amount ELSE 0 END) AS debit_sum,
         SUM(CASE WHEN txn_type='Credit' THEN amount ELSE 0 END) AS credit_sum
  FROM dbo.transactions
  GROUP BY DATEFROMPARTS(YEAR(txn_date), MONTH(txn_date), 1)
)
SELECT month_start, txn_count,
       LAG(txn_count) OVER (ORDER BY month_start) AS prev_month_count,
       ROUND(((txn_count - LAG(txn_count) OVER (ORDER BY month_start))*1.0 / LAG(txn_count) OVER (ORDER BY month_start))*100,2) AS mom_growth_pct
FROM monthly;