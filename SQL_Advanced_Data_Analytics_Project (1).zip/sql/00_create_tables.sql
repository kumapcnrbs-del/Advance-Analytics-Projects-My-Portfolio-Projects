CREATE TABLE dbo.customers (
  customer_id INT PRIMARY KEY,
  name NVARCHAR(200),
  gender NVARCHAR(10),
  age TINYINT,
  region NVARCHAR(50),
  account_type NVARCHAR(50),
  join_date DATE,
  income INT
);
CREATE TABLE dbo.accounts (
  account_id VARCHAR(20) PRIMARY KEY,
  customer_id INT NOT NULL,
  account_type NVARCHAR(50),
  balance DECIMAL(18,2),
  interest_rate DECIMAL(5,2),
  open_date DATE,
  FOREIGN KEY (customer_id) REFERENCES dbo.customers(customer_id)
);
CREATE TABLE dbo.transactions (
  txn_id VARCHAR(20) PRIMARY KEY,
  account_id VARCHAR(20) NOT NULL,
  txn_date DATE,
  txn_type NVARCHAR(20),
  amount DECIMAL(18,2),
  merchant_category NVARCHAR(100),
  FOREIGN KEY (account_id) REFERENCES dbo.accounts(account_id)
);